package com.example.demo01.controller;

import com.example.demo01.dao.Device.DeviceServiceImp;
import com.example.demo01.model.Device;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DeviceController {
    @Autowired
    DeviceServiceImp deviceServiceImp;
    @RequestMapping(value = "/getData", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    public List<Device> getData()
    {
        List<Device> temps = deviceServiceImp.getTemps();
        return temps;
    }

    @GetMapping("/Hello")
    public String Hello()
    {
        return "hello";
    }
}
