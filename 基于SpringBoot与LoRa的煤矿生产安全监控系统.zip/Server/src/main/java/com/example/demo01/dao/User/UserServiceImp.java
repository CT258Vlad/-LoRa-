package com.example.demo01.dao.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

@Service
public class UserServiceImp {

    @Resource
    @Autowired
    UserMapper userMapper;
    public Map<String, Object> UserLogin(String LoginName)
    {
        return userMapper.UserLogin(LoginName);
    }

    public int addUser(Map<String, Object> param){
        return userMapper.addUser(param);
    }

    public int UpdateUserInfo(Map<String, Object>param){
        return userMapper.UpdateUserInfo(param);
    }

    public int DeleteUserInfo(Map<String, Object> param){
        return userMapper.DeleteUserInfo(param);
    }
}
