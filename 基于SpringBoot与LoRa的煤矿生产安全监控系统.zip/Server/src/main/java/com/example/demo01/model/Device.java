package com.example.demo01.model;

import java.sql.Timestamp;

public class Device {
    private int id;
    private String temp;
    private String fire;
    private String gas;
    private String co;
    private String human;
    private Timestamp time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getFire() {
        return fire;
    }

    public void setFire(String fire) {
        this.fire = fire;
    }

    public String getGas() {
        return gas;
    }

    public void setGas(String gas) {
        this.gas = gas;
    }

    public String getCo() {
        return co;
    }

    public void setCo(String co) {
        this.co = co;
    }

    public String getHuman() {
        return human;
    }

    public void setHuman(String human) {
        this.human = human;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "Device{" +
                "id=" + id +
                ", temp='" + temp + '\'' +
                ", fire='" + fire + '\'' +
                ", gas='" + gas + '\'' +
                ", co='" + co + '\'' +
                ", human='" + human + '\'' +
                ", time=" + time +
                '}';
    }
}