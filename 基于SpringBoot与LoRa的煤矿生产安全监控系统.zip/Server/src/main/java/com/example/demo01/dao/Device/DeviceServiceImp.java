package com.example.demo01.dao.Device;

import com.example.demo01.model.Device;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class DeviceServiceImp {
    @Resource
    @Autowired
    DeviceMapper deviceMapper;
    public int addTemp(Device device){
        return deviceMapper.addTemp(device);
    }

    public List<Device> getTemps()
    {
        return deviceMapper.getTempsInFive();
    }
}