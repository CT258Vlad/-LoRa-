package com.example.demo01.UDPServer;

import com.example.demo01.dao.Device.DeviceMapper;
import com.example.demo01.model.Device;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.IOException;
import java.net.*;

@Component
public class UDPServer implements Runnable  {

    @Autowired
    @Resource
    private DeviceMapper tempMapper_udp_save;
    public static UDPServer udpServer;
    String str2;
    String str3;
    String str4;
    String str5;
    String temp;
    String fire;
    String gas;
    String co;
    String human;
    @PostConstruct
    public void init(){
        udpServer = this;
        udpServer.tempMapper_udp_save = this.tempMapper_udp_save;
    }

    public static void addTemp(String temp,String co,String gas, String fire, String human)
    {
        Device device = new Device();
        device.setTemp(temp);
        device.setCo(co);
        device.setGas(gas);
        device.setFire(fire);
        device.setHuman(human);
        udpServer.tempMapper_udp_save.addTemp(device);
    }

    @Override
    public void run() {
        DatagramSocket datagramSocket = null;
        try {
            datagramSocket = new DatagramSocket(2000);
        } catch (SocketException e) {
            datagramSocket.close();
            e.printStackTrace();
        }
        while(true)
        {
            try {
                byte[] buf = new byte[1024];
                DatagramPacket datagramPacket = new DatagramPacket(buf, buf.length);
                datagramSocket.receive(datagramPacket);
                System.out.println("接收端接收到的数据："+ new String(buf,0,datagramPacket.getLength()));
                String string = new String(buf,0,datagramPacket.getLength());
                System.out.println(string);
                String[] strArr1 = StringUtils.split(string,"t");

                for(int i = 0; i < strArr1.length; i++){
                    temp = strArr1[0];
                    str2 = strArr1[1];
                }
                String[] strArr2 = StringUtils.split(str2,"c");
                for (int i = 0; i < strArr2.length; i++){
                    co = strArr2[0];
                    str3 = strArr2[1];
                }
                String[] strArr3 = StringUtils.split(str3,"a");
                for (int i=0; i < strArr3.length; i++){
                    gas = strArr3[0];
                    str4 = strArr3[1];
                }
                String[] strArr4 = StringUtils.split(str4,"f");
                for (int i = 0; i < strArr4.length; i++){
                    fire = strArr4[0];
                    str5 = strArr4[1];
                }
                String[] strArr5 = StringUtils.split(str5,"h");
                for (int i = 0; i < strArr5.length; i++){
                    human = strArr5[0];
                }
                System.out.println("温度:"+temp);
                System.out.println("一氧化碳:"+co);
                System.out.println("烟雾:"+gas);
                System.out.println("火焰:"+fire);
                System.out.println("人员:"+human);

                addTemp(temp,co,gas,fire,human);
                Thread.sleep(100);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}