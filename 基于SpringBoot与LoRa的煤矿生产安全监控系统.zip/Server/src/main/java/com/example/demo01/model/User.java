package com.example.demo01.model;

public class User {
    private int id;
    private String LoginName;
    private String LoginPassword;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLoginNameInfo() {
        return LoginName;
    }

    public void setLoginNameInfo(String loginNameInfo) {
        LoginName = loginNameInfo;
    }

    public String getLoginPassword() {
        return LoginPassword;
    }

    public void setLoginPassword(String loginPassword) {
        LoginPassword = loginPassword;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", LoginNameInfo='" + LoginName + '\'' +
                ", LoginPassword='" + LoginPassword + '\'' +
                '}';
    }
}