package com.example.demo01.controller;

import com.example.demo01.dao.User.UserServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.alibaba.fastjson.JSONObject;

import java.util.HashMap;
import java.util.Map;

@RestController
public class LoginController {
//    Logger logger = LoggerFactory.getLogger(LoginController.class);
    @Autowired
    UserServiceImp userServiceImp;

    @RequestMapping(value = "/User/UserLogin", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    private String UserLogin(@RequestBody String LoginJSON) throws Exception {
        JSONObject LoginJson = JSONObject.parseObject(LoginJSON);
        //获取登录名与登录密码
        String LoginNameInfo = LoginJson.getString("LoginNameInfo");
        String LoginPasswordInfo = LoginJson.getString("LoginPasswordInfo");
//        logger.info("UserLogin: "+"-----Start-----");
//        logger.info("LoginNameInfo: "+LoginNameInfo+" LoginPassordInfo: "+LoginPasswordInfo);
//        logger.info("UserLogin: "+"-----End-----");
        Map<String,Object> userInfo = userServiceImp.UserLogin(LoginNameInfo);
        JSONObject jsonObject = new JSONObject();
        System.out.println(LoginNameInfo);
        System.out.println(LoginPasswordInfo);
        if(userInfo == null){
            jsonObject.put("flag","0");
            jsonObject.put("msg","账号不存在!");
            return jsonObject.toString();
        }
        else{
            String LoginName = (String) userInfo.get("LoginName");
            String LoginPassword = (String)userInfo.get("LoginPassword");
            System.out.println(LoginName);
            System.out.println(LoginPassword);
            if(LoginPasswordInfo.equals(LoginPassword)){
                jsonObject.put("flag",1);
                jsonObject.put("msg","登录成功!");
            }
            else {
                jsonObject.put("flag", "0");
                jsonObject.put("msg", "账号或者密码错误");
            }
        }
        return jsonObject.toString();
    }

    @RequestMapping(value = "/User/addUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    private String addUser(@RequestBody String addJSON) throws Exception{
        JSONObject AddJson = JSONObject.parseObject(addJSON);
        String LoginName = AddJson.getString("LoginName");
        String LoginPassword = AddJson.getString("LoginPassword");

        Map<String ,Object> param = new HashMap<>();
        param.put("LoginName",LoginName);
        param.put("LoginPassword",LoginPassword);

        JSONObject jsonObject = new JSONObject();
        try{
            userServiceImp.addUser(param);
            jsonObject.put("flag","1");
            jsonObject.put("msg","注册成功");
        }catch (Exception e){
            jsonObject.put("flag","0");
            jsonObject.put("msg","注册失败，用户已存在!");
        }
        return jsonObject.toString();
    }

    @RequestMapping(value = "/User/UpdateUserInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    private String UpdateUserInfo(@RequestBody String UpdateJSON) throws Exception{
        JSONObject UpdateJson = JSONObject.parseObject(UpdateJSON);
        String LoginName = UpdateJson.getString("LoginName");
        String LoginPassword = UpdateJson.getString("LoginPassword");
        String id = UpdateJson.getString("#id");
        Map<String, Object> param = new HashMap<>();
        param.put("LoginName",LoginName);
        param.put("LoginPassword",LoginPassword);
        int result= userServiceImp.UpdateUserInfo(param);
        JSONObject jsonObject = new JSONObject();
        if(result == 1){
            jsonObject.put("flag","1");
            jsonObject.put("msg","更新成功");
        }else{
            jsonObject.put("flag","0");
            jsonObject.put("msg","更新失败");
        }
        return jsonObject.toString();
    }

    @RequestMapping(value = "/User/DeleteUserInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    private String DeleteUserInfo(@RequestBody String DeleteJSON) throws Exception{
        JSONObject DeleteJson = JSONObject.parseObject(DeleteJSON);
        String id = DeleteJson.getString("id");

        Map<String ,Object> param = new HashMap<>();
        int i = Integer.parseInt(id);
        param.put("id",i);
        int result = userServiceImp.DeleteUserInfo(param);
        JSONObject jsonObject = new JSONObject();

        if (result !=0 ){
            jsonObject.put("flag","1");
            jsonObject.put("msg","删除成功");
        }else {
            jsonObject.put("flag","0");
            jsonObject.put("msg","删除失败");
        }
        return jsonObject.toString();
    }
}