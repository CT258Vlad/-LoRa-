package com.example.demo01.dao.Device;

import com.example.demo01.model.Device;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface DeviceMapper {
    int addTemp(Device device);
    List<Device> getTempsInFive();
}
