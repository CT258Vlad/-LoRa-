$(document).ready(function(){
    var temp;var fire;var temp;var fire;var gas;var co;var human;
    $.ajax
    ({
        async:true,
        type: "GET",
        url: "http://47.93.193.52:8080/getData",
        dataType: "json",
        data: JSON.stringify(),
        contentType: "application/json",
        success: function (res) {
            console.log(res)
            for(var i=0; i<res.length; i++){
                var time = res[i].time.substring(0,res[i].time.length-9);
                time = time.replace("T"," ");
                temp = parseInt(res[0].temp);
                fire = parseInt(res[0].fire);
                gas = parseInt(res[0].gas);
                co = parseInt(res[0].co);
                human = parseInt(res[0].human);
                tr = '<td id="time">' +time+'</td>'
                    +'<td id="temp">' +res[i].temp+'</td>'
                    +'<td id="fire">' +res[i].fire+'</td>'
                    +'<td id="gas">'  +res[i].gas+'</td>'
                    +'<td id="co">'   +res[i].co+'</td>'
                    +'<td id="human">'+res[i].human+'</td>';
                $("#table").append('<tr id="current" style="height: 30px; align-content: center">' + tr + '</tr>');
            }
        }
    });
    var State;
    if((temp > 40)||(fire == 1)||(gas > 5)||(co > 10)){
        State = "警告";
    }else if((temp > 40)&&(fire == 1)&&(gas > 10)&&(co > 15)&&(human == 1)){
        State = "危险";
    }else {
        State = "安全";
    }
    var audit_1 = new Vue({
        el:'#audit_1',
        data: {
            Situation: State,
        }
    });
})