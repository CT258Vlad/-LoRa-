$(document).ready(function(){
    var UserName;
    var LoginName;
    var LoginPassword;
    $("#entry_reg").click(function () {
        $("#entry_reg").mouseenter(function(){
            $("#entry_reg").css("background-color","WhiteSmoke");
        });
        $("#entry_reg").mouseleave(function(){
            $("#entry_reg").css("background-color","lightgray");
        });
        window.location.href="register.html";
    })
    $("#entry_btn").click(function () {
        $("#entry_btn").mouseenter(function(){
            $("#entry_btn").css("background-color","WhiteSmoke");
        });
        $("#entry_btn").mouseleave(function(){
            $("#entry_btn").css("background-color","lightgray");
        });
        LoginName = $("#username").val();
        LoginPassword = $("#password").val();
        $.ajax
        ({
            async:true,
            type: "POST",
            url: "http://47.93.193.52:8080/User/UserLogin",
            dataType: "json",
            data: JSON.stringify({
                "LoginNameInfo": LoginName,
                "LoginPasswordInfo": LoginPassword,
            }),
            contentType: "application/json",
            success: function (data) {
                console.log(data);
                var flag = data.flag;
                if(flag == 1){
                    alert(data.msg);
                    window.location.href="index.html";
                    UserName = LoginName;
                    localStorage.setItem('Name',UserName);
                }else{
                    alert("登录失败");
                }
            }
        })
    })
})