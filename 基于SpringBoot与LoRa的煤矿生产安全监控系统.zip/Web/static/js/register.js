$(document).ready(function(){
    var UserName;
    var LoginName;
    var LoginPassword;
    $("#register_btn").click(function () {
        $("#register_btn").mouseenter(function(){
            $("#register_btn").css("background-color","WhiteSmoke");
        });
        $("#register_btn").mouseleave(function(){
            $("#register_btn").css("background-color","lightgray");
        });
        LoginName = $("#username").val();
        LoginPassword = $("#password").val();
        var confirm_pwd = $("#confirm_password").val();
        if(LoginPassword == confirm_pwd){
            $.ajax
            ({
                async:true,
                type: "POST",
                url: "http://47.93.193.52:8080/User/addUser",
                dataType: "json",
                data: JSON.stringify({
                    "LoginName": LoginName,
                    "LoginPassword": LoginPassword,
                }),
                contentType: "application/json",
                success: function (data) {
                    console.log(data);
                    var flag = data.flag;
                    if(flag == 1){
                        alert(data.msg);
                    }else{
                        alert("注册失败");
                    }
                }
            })
        }
    })
    $("#back").click(function () {
        $("#back").mouseenter(function () {
            $("#back").css("background-color", "WhiteSmoke");
        });
        $("#back").mouseleave(function () {
            $("#back").css("background-color", "lightgray");
        });
        window.location.href="login.html";
    });
})